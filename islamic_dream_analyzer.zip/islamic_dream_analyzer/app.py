import streamlit as st 
from predict import predict_dream_sentiment
from meaning_lookup import get_meaning_from_csv
from database import init_db, save_dream, get_weekly_sentiments
import altair as alt

# Initialize database
init_db()

# Page config
st.set_page_config(page_title="Islamic Dream Analyzer", layout="wide")

# Custom CSS for style
st.markdown("""
    <style>
    body {
        background: linear-gradient(to right, #a8edea, #fed6e3);
    }
    .stApp {
        background-color: #f9f9f9;
        border-radius: 15px;
        padding: 1rem;
    }
    .sidebar .sidebar-content {
        background-color: #e0f7fa;
    }
    </style>
""", unsafe_allow_html=True)

# Sidebar navigation
st.sidebar.title("🕌 Islamic Dream Analyzer")
menu = st.sidebar.radio("Navigate", ["🏠 Dream Analyzer", "📊 Dream Tracker"])

if menu == "🏠 Dream Analyzer":
    st.title("🛌 Dream Analyzer")
    st.markdown("Analyze your dreams with emotional and Islamic perspective.")

    # Input area
    dream_input = st.text_area("✍️ Enter your dream (Roman Urdu or English):", height=200)

    # Analyze button
    if st.button("🔍 Analyze Dream"):
        if dream_input.strip() == "":
            st.warning("Please enter a dream to analyze.")
        else:
            with st.spinner("Analyzing..."):
                sentiment, islamic_sentiment = predict_dream_sentiment(dream_input)
                save_dream(dream_input, sentiment, islamic_sentiment)

            st.success("✅ Analysis Complete!")
            st.write(f"**Sentiment (Emotion):** `{sentiment.capitalize()}`")
            st.write(f"**Islamic Perspective:** `{islamic_sentiment.capitalize()}`")

            # Dream meaning
            st.subheader("🌙 Dream Meaning")
            meaning_result = get_meaning_from_csv(dream_input)
            st.text(meaning_result)

elif menu == "📊 Dream Tracker":
    st.title("📊 Islamic Dream Tracker")
    st.markdown("Weekly stats of dreams and their sentiments.")

    weekly_df = get_weekly_sentiments()

    if not weekly_df.empty:
        # Emotional Sentiment Chart
        st.subheader("📈 Emotional Sentiment")
        daily_sentiment = weekly_df.groupby(['timestamp', 'sentiment']).size().reset_index(name='count')
        chart = alt.Chart(daily_sentiment).mark_bar().encode(
            x='timestamp:T',
            y='count:Q',
            color='sentiment:N'
        ).properties(width=700, height=300)
        st.altair_chart(chart)

        # Islamic Sentiment Chart
        st.subheader("🕌 Islamic Sentiment")
        islamic_chart = alt.Chart(
            weekly_df.groupby(['timestamp', 'islamic_sentiment']).size().reset_index(name='count')
        ).mark_line(point=True).encode(
            x='timestamp:T',
            y='count:Q',
            color='islamic_sentiment:N'
        ).properties(width=700, height=300)
        st.altair_chart(islamic_chart)
    else:
        st.info("No dream data available from the past 7 days.")

# Footer
st.markdown("---")
st.markdown("📌 *This tool provides emotional and Islamic insights based on your dream input.*")
