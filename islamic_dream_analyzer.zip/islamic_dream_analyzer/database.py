import sqlite3
from datetime import datetime, timedelta
import pandas as pd

# STEP 1: Create / connect to SQLite database and table
def init_db():
    conn = sqlite3.connect("dreams.db")
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS dreams (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        text TEXT,
        sentiment TEXT,
        islamic_sentiment TEXT,
        timestamp TEXT
    )''')
    conn.commit()
    conn.close()

# STEP 2: Save a dream into the database
def save_dream(text, sentiment, islamic_sentiment):
    conn = sqlite3.connect("dreams.db")
    c = conn.cursor()
    c.execute("INSERT INTO dreams (text, sentiment, islamic_sentiment, timestamp) VALUES (?, ?, ?, ?)",
              (text, sentiment, islamic_sentiment, datetime.now().isoformat()))
    conn.commit()
    conn.close()

# STEP 3: Get dreams from the last 7 days for sentiment tracking
def get_weekly_sentiments():
    conn = sqlite3.connect("dreams.db")
    c = conn.cursor()
    seven_days_ago = (datetime.now() - timedelta(days=7)).isoformat()
    c.execute("SELECT timestamp, sentiment, islamic_sentiment FROM dreams WHERE timestamp >= ?", (seven_days_ago,))
    rows = c.fetchall()
    conn.close()

    df = pd.DataFrame(rows, columns=["timestamp", "sentiment", "islamic_sentiment"])
    df["timestamp"] = pd.to_datetime(df["timestamp"]).dt.date
    return df
