# train_sentiment_model.py

import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import classification_report
import joblib
# STEP 1: Load cleaned and split training/testing data
train_df = pd.read_csv("train_dreams.csv")
test_df = pd.read_csv("test_dreams.csv")
# STEP 2: TF-IDF Vectorization (convert text to numbers)
vectorizer = TfidfVectorizer(max_features=5000)
X_train = vectorizer.fit_transform(train_df['Dream'])
X_test = vectorizer.transform(test_df['Dream'])
# Labels
y_train = train_df['sentiment']
y_test = test_df['sentiment']
# STEP 3: Train Naive Bayes classifier
model = MultinomialNB()
model.fit(X_train, y_train)
# STEP 4: Evaluate model
y_pred = model.predict(X_test)
print("Classification Report:")
print(classification_report(y_test, y_pred))
# STEP 5: Save the model and vectorizer for later use
joblib.dump(model, "sentiment_model.pkl")
joblib.dump(vectorizer, "tfidf_vectorizer.pkl")

print("✅ Model training complete. Files saved: sentiment_model.pkl, tfidf_vectorizer.pkl")





