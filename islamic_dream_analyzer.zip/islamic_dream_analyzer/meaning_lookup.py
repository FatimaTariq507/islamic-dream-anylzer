import pandas as pd

# Load dreams CSV once at top
df = pd.read_csv("Dreams.csv")

def get_meaning_from_csv(user_dream):
    user_dream = user_dream.lower()
    matched_rows = []

    for _, row in df.iterrows():
        dream_text = str(row['Dream']).lower()
        if any(word in dream_text for word in user_dream.split()):
            meaning = row.get('Meaning', '')
            if pd.notna(meaning) and meaning.strip():
                matched_rows.append(f"🟢 {dream_text[:40]}... ➡ {meaning}")

    if matched_rows:
        return "\n".join(matched_rows[:3])  # Return top 3 matches
    else:
        return "⚠️ No meaning found. Try writing more common dream words."
