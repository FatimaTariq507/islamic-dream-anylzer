import joblib

# Load models and vectorizers
sentiment_model = joblib.load("sentiment_model.pkl")
sentiment_vectorizer = joblib.load("tfidf_vectorizer.pkl")
islamic_model = joblib.load("islamic_model.pkl")
islamic_vectorizer = joblib.load("islamic_vectorizer.pkl")

# 🔑 Keyword lists (Roman Urdu + English)
REHMANI_KEYWORDS = [
    'masjid', 'namaz', 'quran', 'noor', 'roshni', 'sukoon',
    'prayer', 'mosque', 'light', 'peace', 'allah', 'worship'
]

SHAITANI_KEYWORDS = [
    'larr', 'cheekh', 'andhera', 'dar', 'jadu',
    'fight', 'scream', 'dark', 'fear', 'magic', 'snake', 'blood'
]

NAFSANI_KEYWORDS = [
    'khana', 'shopping', 'friends', 'school', 'ghar',
    'food', 'mall', 'friend', 'home', 'class', 'market'
]

def clean_text(text):
    """
    Lowercase, remove punctuation/numbers, strip whitespace.
    """
    text = text.lower()
    text = ''.join(char for char in text if char.isalnum() or char.isspace())
    return text.strip()


def keyword_based_islamic_sentiment(text):
    """
    Check keywords for fallback Islamic sentiment.
    """
    text = text.lower()
    if any(word in text for word in REHMANI_KEYWORDS):
        return "Rehmani"
    elif any(word in text for word in SHAITANI_KEYWORDS):
        return "Shaitani"
    elif any(word in text for word in NAFSANI_KEYWORDS):
        return "Nafsani"
    return None

def predict_dream_sentiment(dream_text):
    """
    Predicts both sentiment and Islamic sentiment.
    Uses model + keyword logic.
    """
    cleaned_text = clean_text(dream_text)
    # Normal sentiment prediction
    sent_vec = sentiment_vectorizer.transform([cleaned_text])
    sentiment = sentiment_model.predict(sent_vec)[0]
    # Islamic sentiment via model
    islamic_vec = islamic_vectorizer.transform([cleaned_text])
    islamic_prediction = islamic_model.predict(islamic_vec)[0]
     # Keyword fallback
    keyword_prediction = keyword_based_islamic_sentiment(dream_text)
    # Prefer model, else fallback to keywords
    final_islamic = islamic_prediction if islamic_prediction else keyword_prediction
    return sentiment, final_islamic





