import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report
import joblib

# Load training data
train_df = pd.read_csv("train_dreams.csv")
test_df = pd.read_csv("test_dreams.csv")
# TF-IDF vectorizer
vectorizer = TfidfVectorizer(max_features=5000)
X_train = vectorizer.fit_transform(train_df['Dream'])
X_test = vectorizer.transform(test_df['Dream'])
# Labels for Islamic sentiment
y_train = train_df['islamic_sentiment']
y_test = test_df['islamic_sentiment']
# Train Logistic Regression
model = LogisticRegression(max_iter=1000)
model.fit(X_train, y_train)
# Evaluate model
y_pred = model.predict(X_test)
print("Islamic Sentiment Classification Report:")
print(classification_report(y_test, y_pred))
# Save model and vectorizer
joblib.dump(model, "islamic_model.pkl")
joblib.dump(vectorizer, "islamic_vectorizer.pkl")

print("✅ Logistic Regression model for Islamic sentiment saved.")











