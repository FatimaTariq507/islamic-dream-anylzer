# clean_and_split.py
import pandas as pd
from sklearn.model_selection import train_test_split
# STEP 1: Load the combined dataset
df = pd.read_csv("Dreams.csv")  # Make sure file is in the same directory
# STEP 2: Clean the 'Dream' text column
def clean_text(text):
    """
    Convert to lowercase, remove punctuation and numbers, and strip whitespace.
    """
    if pd.isnull(text):
        return ""
    text = str(text).lower()
    text = ''.join(char for char in text if char.isalnum() or char.isspace())
    return text.strip()
df['Dream'] = df['Dream'].apply(clean_text)
# STEP 3: Rename columns to simple names for easier use
df = df.rename(columns={
    'Sentiment Analysis': 'sentiment',
    'Islamic Analysis': 'islamic_sentiment',
    'Meaning': 'meaning'
})
# STEP 4: Check required columns exist
required_columns = ['Dream', 'sentiment', 'islamic_sentiment', 'meaning']
for col in required_columns:
    if col not in df.columns:
        raise ValueError(f"Missing required column: {col}")
# STEP 5: Split data into train and test (80/20), stratified on sentiment
train_df, test_df = train_test_split(df, test_size=0.2, random_state=42, stratify=df['sentiment'])
# STEP 6: Save outputs
train_df.to_csv("train_dreams.csv", index=False)
test_df.to_csv("test_dreams.csv", index=False)
print("✅ Success! Cleaned and split Dreams.csv into train_dreams.csv and test_dreams.csv")








